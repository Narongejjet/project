{/* Boonyarit Modepeng Benz add scrollup to all pages -->*/}
import '../styles/globals.css'

import Scrollup from './components/main/Scrollup'
export default function App({ Component, pageProps }) {
  return (
<>

<Scrollup/>
<Component {...pageProps} />


    </>
  )
  
}
