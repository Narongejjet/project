{/* Boonyarit Modepeng Benz hamburger button appear when shrink page to mobile*/}
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {  Drawer } from 'antd';
import { useState } from 'react';
import { faBars } from '@fortawesome/free-solid-svg-icons';
import Link from 'next/link';
const App = () => {
  const [open, setOpen] = useState(false);
  const showDrawer = () => {
    setOpen(true);
  };
  const onClose = () => {
    setOpen(false);
  };
  return (
    <>
      <div id="bar-btn" className="search"><FontAwesomeIcon className='fabar' icon={faBars} onClick={showDrawer} /></div>
      <Drawer className='Home' title="Home" placement="left" onClose={onClose} open={open}>
            <p><Link href="/">สินค้าขายดี</Link></p>
            <br />
            <p><Link href="/">สินค้าโปรโมชั่น</Link></p>
            <br />
            <p><Link href="/">สินค้ามาใหม่</Link></p>
            <br />
            <p><Link href="/">รวมคูปองส่วนลด</Link></p>
            <br />
            <p><Link href="/">Flash sale</Link></p>
      </Drawer>
    </>
  );
};
export default App;