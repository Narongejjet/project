{/* Boonyarit Modepeng Benz -->*/}
import * as React from 'react';
import { useEffect,useState } from 'react';
import Box from '@mui/material/Box';
import Avatar from '@mui/material/Avatar';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Link from 'next/link';
import Tooltip from '@mui/material/Tooltip';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import Logout from '@mui/icons-material/Logout';
import LoginIcon from '@mui/icons-material/Login';

export default function AccountMenu() {
  //Remove token when logged out
  const handle = ()=>{
    localStorage.removeItem("token");
    window.location="/"
  } 
//Get username and lastname when logged in
  const [user, setUser] = useState({ firstName: '', lastName: '' });
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const [loggedIn, setLoggedIn] = useState(false);
  useEffect(()=>{ 
    if (localStorage.getItem("token")) {
      setLoggedIn(true);
    }
    function getUser() {
      const gtoken = localStorage.getItem("token")
      console.log(gtoken);
        // Make API call to retrieve user information
        fetch('http://localhost:3333/getlogin',{method:"get",headers:{"authorization":gtoken}})
          .then(response => response.json())
          .then(data => {
            setUser({ firstName: data[0].fname, lastName: data[0].lname });
            console.log(data[0]);
          
          })
          .catch((error) => {
            console.error('Error:', error);
          });
      }
      getUser()

      
  const searchForm = document.querySelector('.search-form');
  document.querySelector('#search-btn').onclick = () => {
    searchForm.classList.toggle('active');
  }
  },[])
  


  return (
    <React.Fragment>
      <Box sx={{ display: 'inline', alignItems: 'center', textAlign: 'center' }}>
        <Tooltip title="Profile">
          <IconButton
            onClick={handleClick}
            size="small"
            aria-controls={open ? 'account-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={open ? 'true' : undefined}
          >
            <AccountCircleIcon sx={{ width: 35, height: 35 }}></AccountCircleIcon>
          </IconButton>
        </Tooltip>
      </Box>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: 'visible',
            filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
            mt: 1.5,
            '& .MuiAvatar-root': {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            '&:before': {
              content: '""',
              display: 'block',
              position: 'absolute',
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: 'background.paper',
              transform: 'translateY(-50%) rotate(45deg)',
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        <MenuItem>
          <Avatar /> <p className="user-name">{user.firstName} {user.lastName}</p>
        </MenuItem>
        <Divider />
        { !loggedIn && (
  <Link href="/Login" className='user'>
    <MenuItem>
      <ListItemIcon>
        <LoginIcon fontSize="small" />
      </ListItemIcon>
      Login
    </MenuItem>
  </Link>
) }
        <MenuItem>
          <ListItemIcon>
            <Logout fontSize="small" />
          </ListItemIcon>
          <button className='logout' onClick={handle}>Logout</button>
        </MenuItem>
      </Menu>
    </React.Fragment>
  );
}