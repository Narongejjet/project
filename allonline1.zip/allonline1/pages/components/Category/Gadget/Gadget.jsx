{/* Boonyarit Modepeng Benz desgin page*/}
import React from 'react'
import Navbar from '../../header/Navbar'
import Footer from '../../Footer/Footer'
import Catg from '../Beauty/Catg'
import Gadgetcart from './Gadgetcart'

import Style from './Style.module.css'

function Gadget() {
  return (
    <>
    <Navbar/>
    <section className='scat background'>
        <div className='container d_flex'>
          <Catg />

          <div className={Style.contentWidth}>
            <div className='heading d_flex'>
            <div className='heading-left row  f_flex'>
                <h2 className={Style.ctitle}>อุปกรณ์ไอทีและกล้อง</h2>
              </div>
            </div>
            <div className='product-content  grid10'>
              <Gadgetcart/>
            </div>
          </div>
        </div>
      </section>
    <Footer/>
    </>
  )
}

export default Gadget