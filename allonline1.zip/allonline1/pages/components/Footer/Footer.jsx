{/* Boonyarit Modepeng Benz Footer design*/}
import React from "react"
import Image from "next/image"
import App from "../../../public/img/pay/appstore.png"
import Play from "../../../public/img/pay/playstore.png"
import QR from '../../../public/img/pay/Qr.jpg'
import Ig from "../../../public/img/social/instagram.png"
import Fb from "../../../public/img/social/facebook.png"
import Yt from "../../../public/img/social/youtube.png"
import Tw from "../../../public/img/social/twitter.png"
import Li from "../../../public/img/social/line.png"
import Link from "next/link"
const Footer = () => {
  return (
    <>
      <footer className="footer1">
        <div className='ft grid2'>
          <div className="box Ultra">
          <div className='box'>
            <h1>ดาวน์โหลดแอป 7-Eleven</h1>
            
            <div className='Download'>
              <div className="Top">
                <Link href="https://play.google.com/store/apps/details?id=asuk.com.android.app&pli=1">
              
              <Image
              className="Playstore"
                src={Play}
                alt=""
                />
                
                </Link>
              </div>
              <div className="Button">
                <Link href="https://apps.apple.com/th/app/7-eleven-th/id514262377?utm_source=weballonline&utm_medium=icon&utm_campaign=loadappstore">
              <Image
              className="Appstore"
                src={App}
                alt=""
                />
                </Link>
               
              </div>
            </div>
          </div>
          <div className="box Mid">
              <Image
              className="Qr"
                src={QR}
                alt=""
                width={170}
                height={170}
                />
                </div>
          </div>
          <div className='box about'>
            <h2>เกี่ยวกับเรา</h2>
            <ul>
              <li>ข้อตกลงและเงื่อนไข</li>
              <li>การแจ้งการประมวลผลข้อมูลส่วนบุคคลของสมาชิก</li>
              <li>นโยบายการใช้คุกกี้</li>
              <li>ติดต่อเรา</li>
            </ul>
          </div>
          <div className='service'>
            <h2>บริการลูกค้า</h2>
            <ul>
              <li>ศูนย์ช่วยเหลือ</li>
              <li>วิธีสั่งซื้อและชำระเงิน</li>
              <li>วิธีการจัดส่ง</li>
              <li>สถานะการสั่งซื้อ</li>
              <li>ใบส่งสินค้า</li>
              <li>การคืนสินค้าและคืนเงิน</li>
            </ul>
          </div>

          <div className='social'>
            <h2>ติดตามเราได้ที่</h2>
            
          <Link href="https://web.facebook.com/7ElevenThailand/?_rdc=1&_rdr">
          <Image
                className="f"
                src={Fb}
                alt=""
                width={40}
                height={40}
                />
          </Link>
               <Link href="https://www.instagram.com/7.eleventhailand/">
               <Image
                className="i"
                src={Ig}
                alt=""
                width={40}
                height={40}
                />
               </Link>
               <Link href="https://www.youtube.com/channel/UCpu3-NFPc8Fl0WIVsGdb3KA">
               <Image
                className="y"
                src={Yt}
                alt=""
                width={40}
                height={40}
                />
               </Link>
             
           <Link href="https://page.line.me/cpall">
           <Image
                className="l"
                src={Li}
                alt=""
                width={50}
                height={50}
                />
           </Link>
                <Link href="https://twitter.com/7eleventhailand">
                <Image
                className="t"
                src={Tw}
                alt=""
                width={40}
                height={40}
                />
                </Link>
          </div>
        </div>
      </footer>
      <footer className="latest">
      <div className="admin"><Link href="/Admin">Admin</Link></div>
      </footer>
      {/* Footer2 */}
      <div className="collapse">
      <footer className="footer2">
        <div className="csocial">
        <h2>ติดตามเราได้ที่</h2>
            
            <Link href="https://web.facebook.com/7ElevenThailand/?_rdc=1&_rdr">
            <Image
                  className="f"
                  src={Fb}
                  alt=""
                  width={60}
                  height={60}
                  />
            </Link>
                 <Link href="https://www.instagram.com/7.eleventhailand/">
                 <Image
                  className="i"
                  src={Ig}
                  alt=""
                  width={60}
                  height={60}
                  />
                 </Link>
                 <Link href="https://www.youtube.com/channel/UCpu3-NFPc8Fl0WIVsGdb3KA">
                 <Image
                  className="y"
                  src={Yt}
                  alt=""
                  width={60}
                  height={60}
                  />
                 </Link>
               
             <Link href="https://page.line.me/cpall">
             <Image
                  className="l"
                  src={Li}
                  alt=""
                  width={70}
                  height={70}
                  />
             </Link>
                  <Link href="https://twitter.com/7eleventhailand">
                  <Image
                  className="t"
                  src={Tw}
                  alt=""
                  width={60}
                  height={60}
                  />
                  </Link>
        </div>
        <div className='cservice'>
            <h2>บริการลูกค้า</h2>
            <ul>
              <li>ศูนย์ช่วยเหลือ</li>
              <li>วิธีสั่งซื้อและชำระเงิน</li>
              <li>วิธีการจัดส่ง</li>
              <li>สถานะการสั่งซื้อ</li>
              <li>ใบส่งสินค้า</li>
              <li>การคืนสินค้าและคืนเงิน</li>
            </ul>
          </div>
          <div className='cabout'>
            <h2>เกี่ยวกับเรา</h2>
            <ul>
              <li>ข้อตกลงและเงื่อนไข</li>
              <li>การแจ้งการประมวลผลข้อมูลส่วนบุคคลของสมาชิก</li>
              <li>นโยบายการใช้คุกกี้</li>
              <li>ติดต่อเรา</li>
            </ul>
          </div>
        <div className="cDownload">
        <h3>ดาวน์โหลดแอป 7-Eleven</h3>
        <div className='Download'>
              <div className="Top">
              <Link href="https://play.google.com/store/apps/details?id=asuk.com.android.app&pli=1">
              <Image
              className="Playstore"
                src={Play}
                alt=""
                />
                </Link>
              </div>
              <div className="Button">
                <Link href="https://apps.apple.com/th/app/7-eleven-th/id514262377?utm_source=weballonline&utm_medium=icon&utm_campaign=loadappstore">
              <Image
              className="Appstore"
                src={App}
                alt=""
                />
                </Link>
               
              </div>
            </div>
            <div className="box Mid">
              <Image
              className="Qr"
                src={QR}
                alt=""
                />
                </div>
        </div>

      </footer>
      </div>
    </>
  )
}

export default Footer
