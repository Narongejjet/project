{/* Boonyarit Modepeng Benz desgin page*/}
import React from 'react'
import Navbar from '../../header/Navbar'
import Footer from '../../Footer/Footer'
import Catg from '../Beauty/Catg'
import Foodcart from './Foodcart'

import Style from './Style.module.css'

function Food() {
  return (
    <>
    <Navbar/>
    <section className='scat background'>
        <div className='container d_flex'>
          <Catg />

          <div className={Style.contentWidth}>
            <div className='heading d_flex'>
            <div className='heading-left row  f_flex'>
                <h2 className={Style.ctitle}>อาหารและเครื่องดื่ม</h2>
              </div>
            </div>
            <div className='product-content  grid10'>
              <Foodcart/>
            </div>
          </div>
        </div>
      </section>
    <Footer/>
    </>
  )
}

export default Food