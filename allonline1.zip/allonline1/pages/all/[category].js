{/* Boonyarit Modepeng Benz create each category page using dynamic route*/}
import React from 'react'
import { useRouter } from 'next/router'
import Beauty from '../components/Category/Beauty/Beauty'
import Food from '../components/Category/Food&drink/Food'
import Gadget from '../components/Category/Gadget/Gadget'
import Apliance from '../components/Category/Apliance/Apliance'
import('next').GetStaticPaths

function Categoryrender() {
  const router = useRouter()
  const {category} = router.query
  console.log(category);
  // if(category =='อาหารและเครื่องดื่ม')
  if(category == 'ความงาม')
  return (
  <>
  <Beauty/>
  </>
  )
  else if (category == 'อาหารและเครื่องดื่ม') 
  return (
  <>
 <Food/>
  </>
  )
  else if (category == 'อุปกรณ์ไอทีและกล้อง') 
  return (
    <>
<Gadget/>
    </>
    )
    else if (category == 'เครื่องใช้ไฟฟ้า') 
    return (
      <>
      <Apliance/>
      </>
      )


  // else if(category == 'ความงาม')
  // return(
  //   <div>ความงาม</div>
  // )
}

export const getStaticPaths = async ()=>{
  return{
    paths:[
      {params:{category:'อาหารและเครื่องดื่ม'}},
      {params:{category:'ความงาม'}},
      {params:{category:'อุปกรณ์ไอทีและกล้อง'}},
      {params:{category:'เครื่องใช้ไฟฟ้า'}},
    ],
    fallback: false
  }
}

export async function getStaticProps() {
  return {
    // Passed to the page component as props
    props: { cat:{}},
  }
}

export default Categoryrender