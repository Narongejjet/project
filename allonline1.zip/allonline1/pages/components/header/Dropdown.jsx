{/* Boonyarit Modepeng Benz search category design*/}
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCaretDown } from '@fortawesome/free-solid-svg-icons';
import { Dropdown, Space } from 'antd';
import Link from 'next/link';

const items = [
  {
    key: '1',
    label: (
      <Link href="/components/Category/Food&drink/Food">อาหารและเครื่องดื่ม</Link>
    ),
  },
  {
    key: '2',
    label: (
      <Link href="/components/Category/Beauty/Beauty">ความงาม</Link>
        
    
    ),
  
  },
  {
    key: '3',
    label: (
      <Link href="/components/Category/Gadget/Gadget">อุปกรณ์ไอทีและกล้อง</Link>
        
    ),

  },
  {
    key: '4',
    label: (
      <Link href="/components/Category/Apliance/Apliance">เครื่องใช้ไฟฟ้า</Link>
        
    
    ),

  }
];
const App = () => (
  <Dropdown
    menu={{
      items,
    }}
  >
    <a onClick={(e) => e.preventDefault()}>
      <Space>
        หมวดหมู่ทั้งหมด
        <FontAwesomeIcon className='fadrop' icon={faCaretDown} />
      </Space>
    </a>
  </Dropdown>
);
export default App;