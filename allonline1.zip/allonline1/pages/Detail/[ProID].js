{/* Boonyarit Modepeng Benz -->*/}
import axios from 'axios';
import Detail from '../components/Detail/Detail'

export async function getServerSideProps({ params }) {
  
  const { ProID } = params;
  const res = await axios.get(`http://localhost:3001/product/detail/${ProID}`);//Get selected id from product
  console.log(res); 
  const val = res.data;
  console.log(val); 
  return {
    props: { val },
  };
}

function ProductPage({ val }) {
  // console.log(val); 
  
  return (
    
<>
<Detail productlist={val} />

</>
  );
}

export default ProductPage;
