{/* Boonyarit Modepeng Benz*/}
import React from "react"
import Sdata from "./Sdata"
import Slider from "react-slick"
import "slick-carousel/slick/slick.css"
import "slick-carousel/slick/slick-theme.css"
import Image from "next/image"

const SlideCard = () => {
  //Show dot on slidecard
  const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    appendDots: (dots) => {
      return <ul style={{ margin: "0px" }}>{dots}</ul>
    },
  }
  //get&show image from sdata and 
  return (
    <>
      <Slider {...settings}>
        {Sdata.map((value, index) => {
          return (
            <>
              <div className='box d_flex top' key={index}>
             
               
                      <img
                     
         src={value.cover}
         alt=""
       ></img>    
             
              </div>
            </>
          )
        })}
      </Slider>
    </>
  )
}

export default SlideCard
