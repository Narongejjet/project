//Boonyarit Modepeng Benz-->

import axios from 'axios';
import FlashDetail from '../components/Detail/FlashDetail';

export async function getServerSideProps({ params }) {
  const { Flash } = params;
  const res = await axios.get(`http://localhost:3001/product/flash/${Flash}`);//Get selected id from flash product
  console.log(res); // Add this line to check the entire response object
  const val = res.data;
  console.log(val); // Add this line to check the value of val
  return {
    props: { val },
  };
}

function FlashPage({ val }) {
  
  return (
    
<>

<FlashDetail Flash={val}/>
</>
  );
}

export default FlashPage;
