{/* Boonyarit Modepeng Benz product list page-->*/}
import React from "react"
import ShopCart from "./ShopCart"

const Shop = ({shopsearch}) => {

  return (
    <>
      <section className='shop background'>
        <div className='container d_flex'>
        

          <div className='contentWidth'>
            <div className='heading d_flex'>
              <div className='heading-left row  f_flex'>
                <h2>สินค้าแนะนำ</h2>
              </div>
              <div className='heading-right row '>
                <p>ดูทั้งหมด</p>
                <i className='fa-solid fa-caret-right'></i>
              </div>
            </div>
            <div className='product-content  grid1'>
              <ShopCart shopsearch={shopsearch}/>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Shop
