// พลวัต ชาญศิขริน อ๋อง -->
import Success from "./success"
import Bug from "./bug"
import axios from 'axios';
import { useState,useEffect } from 'react';
import addProForms from '../styles/addProForms.module.css'

function AddProForm() {
    const [ProID, setProID] = useState('');
    const [ProIMG, setProIMG] = useState(null);
    const [Proname, setProname] = useState('');
    const [Price, setPrice] = useState('');
    const [Sale, setSale] = useState('');
    const [Flash, setFlash] = useState('');
    const [Description, setDescription] = useState('');
    const [Stock, setStock] = useState('');
    const [Status, setStatus] = useState('');
    const [addStatus, setAddStatus] = useState(null);
   
   

    const handleSubmit = async (e) => {
        e.preventDefault();
        if(!ProID || !ProIMG || !Proname || !Price || !Description || !Stock || !Status) {
            alert("โปรดกรอกข้อมูลให้ครบถ้วน") 
            
            return;
        }
         const formData = new FormData();
        formData.append('ProIMG', ProIMG, ProIMG.name);
        formData.append('ProID', ProID);
        formData.append('Proname', Proname);
        formData.append('Price', Price);
        formData.append('Sale', Sale);
        formData.append('Flash', Flash);
        formData.append('Description', Description);
        formData.append('Stock', Stock);
        formData.append('Status', Status);
        try {
            const response = await axios.post("http://localhost:3001/product/add", formData, {
                headers: {
                    "Content-Type": "multipart/form-data",
                },
            });
            if (response.status === 200) {
                setAddStatus({
                    message: "Add Successful",
                    success: true
                });
            } else {
                setAddStatus({
                    message: "Add Failed",
                    success: false
                });
            }
        } catch (error) {
            setAddStatus({
                message: "Add Error",
                success: false
            });
        }
    }

    useEffect(() => {
        if (addStatus && addStatus.success) {
            setTimeout(() => {
                window.location.reload();
            }, 1000); // 1 seconds
        }
    }, [addStatus]);

    return (
// Boonyarit Modepeng Benz design page & show data -->
        <form onSubmit={handleSubmit} className={addProForms.enter}>
            <div className={addProForms.flex}>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Product ID: </h1></div>
                    <div className={addProForms.boxID}>
                    <input type="text" value={ProID} onChange={e => setProID(e.target.value)} placeholder="Product ID" className={addProForms.boxID}/>
            </div>
            </div>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Import Image: </h1></div>
                    <div className={addProForms.boxIMG}>
                        
                    <input type="file" onChange={e => setProIMG(e.target.files[0])}  className={addProForms.boxIMGS}/>
            </div>
            </div>
            </div>

            <div className={addProForms.flex}>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Product Name: </h1></div>
                    <div className={addProForms.boxP}>
           
                    <input type="text" value={Proname} onChange={e => setProname(e.target.value)} placeholder="Name" className={addProForms.boxP}/>
            </div>
            </div>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Price: </h1></div>
                    <div className={addProForms.box}>
                        
                    <input type="text" value={Price} onChange={e => setPrice(e.target.value)} placeholder="฿" className={addProForms.box}/>
            
            </div>
            </div>
            </div>

            <div className={addProForms.flex}>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Flashsale Price: </h1></div>
                    <div className={addProForms.boxF}>
                    <input type="text" value={Flash} onChange={e => setFlash(e.target.value)} placeholder="฿"  className={addProForms.boxF}/>
                    
            </div>
            </div>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Sale:</h1></div>
                    <div className={addProForms.boxS}>
                        
                   
                    <input type="text" value={Sale} onChange={e => setSale(e.target.value)} placeholder="%" className={addProForms.boxS}/>
            </div>
            </div>
            </div>

            <div className={addProForms.flex}>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Description: </h1></div>
                    <div className={addProForms.boxD}>
                    <input type="text" value={Description} onChange={e => setDescription(e.target.value)} placeholder="Description" className={addProForms.boxD}/>
                    
            </div>
            </div>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Stock:</h1></div>
                    <div className={addProForms.box}>
                        
                   
                    <input type="text" value={Stock} onChange={e => setStock(e.target.value)} placeholder="No." className={addProForms.box}/>
            </div>
            </div>
            </div>
            {/* <input type="text" value={role} onChange={e => setRole(e.target.value)} placeholder="Role" /> */}
            <div className={addProForms.role}>
            <div className={addProForms.rolename}>
                <h1>Status: </h1>
            </div>
            <div className={addProForms.Bgs}>
         <div className={addProForms.Bigr1}>
            <div className={addProForms.input}>
            <input type="radio" name="role" value="มีสินค้า" className={addProForms.input} onChange={(event) => setStatus(event.target.value)}></input>
            </div>
            <div className={addProForms.label}>
            <h1>มีสินค้า</h1>
            </div>
            </div>
            
            <div className={addProForms.Bigr2}>
            <div className={addProForms.input}>
            <input type="radio" name="role" value="ไม่มีสินค้า" className={addProForms.input} onChange={(event) => setStatus(event.target.value)}></input>
            </div>
            <div className={addProForms.label}>
            <h1>ไม่มีสินค้า</h1>
            </div>
            </div>
            </div>
            </div>
            <div className={addProForms.butt}>
            <button type="submit">Add</button>
            </div>
   
    
{addStatus && addStatus.success && <Success message={"Add Successful"} />}
{addStatus && !addStatus.success && <Bug message={"Add Failed"} />} 
        </form>
        
    );
}

export default AddProForm;
// <-- พลวัต ชาญศิขริน อ๋อง