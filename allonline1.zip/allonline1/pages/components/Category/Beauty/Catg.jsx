{/* Boonyarit Modepeng Benz category desgin&linking to dynamic route*/}
import React from "react"
import Style from "./Style.module.css"
import Image from "next/image"
import Link from "next/link"
import Image1 from '../../../../public/img/category/cat1.png' 
import Image2 from '../../../../public/img/category/cat2.png' 
import Image3 from '../../../../public/img/category/cat3.png' 
import Image4 from '../../../../public/img/category/cat4.png' 
const Catg = () => {
  const data = [
    {
      cateImg: Image1,
      cName: "เครื่องใช้ไฟฟ้า",
    },
    {
      cateImg: Image2,
      cName: "อุปกรณ์ไอทีและกล้อง",
    },
    {
      cateImg: Image3,
      cName: "ความงาม",
    },
    {
      cateImg: Image4,
      cName: "อาหารและเครื่องดื่ม",
    },
    
  ]
  return (
    <>
      <div className={Style.catg}>
        <div className='chead d_flex'>
          <h1>หมวดหมู่ทั้งหมด</h1>
        </div>
        {data.map((value, index) => {
          return (
            <div className='box f_flex' key={index}>
            <Image src={value.cateImg} alt="" />
            <Link href="/all/name" as={`/all/${value.cName}`}>
                <p className={`cName${index+1}`}>{value.cName}</p>
            </Link>
        </div>
          )
        })}
      </div>
    </>
  )
}

export default Catg
