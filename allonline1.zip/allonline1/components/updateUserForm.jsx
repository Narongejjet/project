// พลวัต ชาญศิขริน อ๋อง -->
import Success from "./success"
import Bug from "./bug"
import axios from 'axios';
import { useState, useEffect } from 'react';
import Admins from '../styles/Admins.module.css'



function UpdateUserForm() {
    const [id, setID] = useState('');
    const [email, setEmail] = useState('');
    const [fname, setFname] = useState('');
    const [lname, setLname] = useState('');
    const [role, setRole] = useState('');
    const [updateStatus, setUpdateStatus] = useState(null);
   
    

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!id || !email || !fname || !lname || !role) {
            alert("Please fill out all fields.")

            return;
        }
        try {
            const response = await axios.put(`http://localhost:3001/customers/update/${id}`, {
                id,
                email,
                fname,
                lname,
                role
            });
            if (response.status === 200) {
                setUpdateStatus({
                    message: "Update Successful",
                    success: true
                });
            } else {
                setUpdateStatus({
                    message: "Update Failed",
                    success: false
                });
            }
        } catch (error) {
            setUpdateStatus({
                message: "Update Failed",
                success: false
            });
        }

    }

    useEffect(() => {
        if (updateStatus && updateStatus.success) {
            setTimeout(() => {
                window.location.reload();
            }, 1000); // 1 seconds
        }
    }, [updateStatus]);

{/* Boonyarit Modepeng Benz design form-->*/}
    return (
       
            
        <form onSubmit={handleSubmit}>
       
            <div className={Admins.mama}>

                <div className={Admins.bigger}>
                    <div className={Admins.name}><h1>Customer ID: </h1></div>
                    <div className={Admins.box}>
                        <input type="text" value={id} onChange={e => setID(e.target.value)} placeholder="Customer ID" className={Admins.box} />
                    </div>
                </div>
                <div className={Admins.bigger}>
                <div className={Admins.name}><h1>Email: </h1></div>
                    <div className={Admins.boxE}>
                        <input type="text" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" className={Admins.boxE} />
                    </div>
                </div>
                <div className={Admins.bigger}>
                <div className={Admins.name}><h1>First name: </h1></div>
                    <div className={Admins.boxB}>
                        <input type="text" value={fname} onChange={e => setFname(e.target.value)} placeholder="First Name" className={Admins.boxB} />
                    </div>
                </div>
                <div className={Admins.bigger}>
                <div className={Admins.name}><h1>Last name: </h1></div>
                    <div className={Admins.boxB}>
                        <input type="text" value={lname} onChange={e => setLname(e.target.value)} placeholder="Last Name" className={Admins.boxB} />
                    </div>
                </div>
            </div>
           
           <div className={Admins.role}>
            <div className={Admins.rolename}>
                <h1>Role: </h1>
            </div>
            <div className={Admins.Bgs}>
         <div className={Admins.Bigr1}>
            <div className={Admins.input}>
                <input type="radio" name="role" value="admin" className={Admins.input} onChange={(event) => setRole(event.target.value)} ></input>
            </div>
            <div className={Admins.label}>
            <h1>Admin</h1>
            </div>
            </div>
            
            <div className={Admins.Bigr2}>
            <div className={Admins.input}>
            <input type="radio" name="role" value="user" className={Admins.input} onChange={(event) => setRole(event.target.value)} />
            </div>
            <div className={Admins.label}>
            <h1>User</h1>
            </div>
            </div>
            </div>
            </div>
            <div className={Admins.butt}>
            <button type="submit">Update</button>
            </div>
            {updateStatus && updateStatus.success && <Success message={"Update Successful"} />}
            {updateStatus && !updateStatus.success && <Bug message={"Update Failed"} />}
        
        </form>
        
 

    );
    {/* <--Boonyarit Modepeng Benz */}
}

export default UpdateUserForm;
{/* <--// พลวัต ชาญศิขริน อ๋อง */}