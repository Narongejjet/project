// พลวัต ชาญศิขริน อ๋อง-->
import Success from "./success"
import Bug from "./bug"
import addProForms from '../styles/addProForms.module.css'
 import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faRectangleXmark } from "@fortawesome/free-solid-svg-icons";
import Admins from '../styles/Admins.module.css'
import axios from 'axios';
import Product from '../styles/Product.module.css'
import { MDBTable, MDBTableHead, MDBTableBody } from 'mdb-react-ui-kit';

function UpdateProForm({ProID}) {
  const [ProIMG, setProIMG] = useState(null);
  const [Proname, setProname] = useState('');
  const [Price, setPrice] = useState('');
  const [Sale, setSale] = useState('');
  const [Flash, setFlash] = useState('');
  const [Description, setDescription] = useState('');
  const [Stock, setStock] = useState('');
  const [Status, setStatus] = useState('');
  const [updateStatus, setUpdateStatus] = useState(null);
  const [product, setProduct] = useState({});

  const [anchorEl, setAnchorEl] = React.useState(null);
  const handleClose = () => {
      setAnchorEl(null);
    };

  useEffect(() => {
    axios
      .get(`http://localhost:3001/product/${ProID}`)
      .then((response) => {
        setProduct(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [ProID]);

    useEffect(() => {
      if (product.ProID) {
        setProname(product.Proname);
        setPrice(product.Price);
        setSale(product.Sale);
        setFlash(product.Flash);
        setDescription(product.Description);
        setStock(product.Stock);
        setStatus(product.Status);
      }
    }, [product]);

    const handleSubmit = async (e) => {
      e.preventDefault();
    
      const formData = new FormData();
      formData.append('ProID', ProID);
      formData.append('ProIMG', ProIMG);
      formData.append('Proname', Proname);
      formData.append('Price', Price);
      formData.append('Sale', Sale);
      formData.append('Flash', Flash);
      formData.append('Description', Description);
      formData.append('Stock', Stock);
      formData.append('Status', Status);
      try {
        const response = await axios.put(`http://localhost:3001/product/update/${ProID}`, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        if (response.status === 200) {
          setUpdateStatus({
            message: 'Update Successful',
            success: true,
          });
        } else {
          console.error(`Update failed with status code ${response.status}`);
          setUpdateStatus({
            message: 'Update Failed',
            success: false,
          });
        }
      } catch (error) {
        console.error(error);
        setUpdateStatus({
          message: 'Update Error',
          success: false,
        });
      }
    };

    useEffect(() => {
      if (updateStatus && updateStatus.success) {
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      }
    }, [updateStatus]);
// <-- พลวัต ชาญศิขริน อ๋อง

{/* Boonyarit Modepeng Benz desgin table&form-->*/}
    return (
      <>
       <form>
              <div className={Admins.Eform}>
               
             <button className={Admins.close}><i><FontAwesomeIcon  icon={ faRectangleXmark } onClick={() => { handleClose();}} /></i></button>
           
             </div>
             </form>
     
        <form onSubmit={handleSubmit} className={addProForms.enter}>
          <div>
          <MDBTable>
  <MDBTableHead dark>
    <tr className={Product.center}>
      <th scope='col'>ProductID</th>
      <th scope="col">Image</th>
      <th scope="col">Name</th>
      <th scope="col">Price</th>
      <th scope="col">Sale</th>
      <th scope="col">Flashsale</th>
      <th scope="col">Description</th>
      <th scope="col">Stock</th>
      <th scope="col">Status</th>
    </tr>
  </MDBTableHead>
  {product && (
    <MDBTableBody>
      <tr className={Product.all} key={product.ProID}>
        <td>
          <span>{product.ProID}</span>
        </td>
        <td>
          <img src={`/storage/${product.ProIMG}`} alt="" width={100} />
        </td>
        <td>
          <span>{product.Proname}</span>
        </td>
        <td>
          <span>{product.Price}</span>
        </td>
        <td>
          <span>{product.Sale}</span>
        </td>
        <td>
          <span>{product.Flash}</span>
        </td>
        <td>
          <span>{product.Description}</span>
        </td>
        <td>
          <span>{product.Stock}</span>
        </td>
        <td>
          <span>{product.Status}</span>
        </td>
      </tr>
    </MDBTableBody>
  )}
</MDBTable>

          </div>
      
            <div className={addProForms.flex}>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Import Image: </h1></div>
                    <div className={addProForms.boxIMG}>
                    <input type="file"  onChange={e => setProIMG(e.target.files[0])} placeholder="Import Image" className={addProForms.boxIMGS}/>
            </div>
            </div>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Price: </h1></div>
                    <div className={addProForms.box}>
           
                    <input type="text" value={Price} onChange={e => setPrice(e.target.value)} placeholder="฿" className={addProForms.box}/>
            </div>
            </div>
            </div>

            <div className={addProForms.flex}>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Product name: </h1></div>
                    <div className={addProForms.box}>
                    <input type="text" value={Proname} onChange={e => setProname(e.target.value)} placeholder="Name" className={addProForms.box}/>
            </div>
            </div>
            
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Sale: </h1></div>
                    <div className={addProForms.box}>
                        
                    <input type="text" value={Sale} onChange={e => setSale(e.target.value)} placeholder="%" className={addProForms.box}/>
            
            </div>
            </div>
            </div>

            <div className={addProForms.flex}>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Flashsale Price: </h1></div>
                    <div className={addProForms.boxFS}>
                    <input type="text" value={Flash} onChange={e => setFlash(e.target.value)} placeholder="฿" className={addProForms.boxFS}/>
                    
            </div>
            </div>
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Stock: </h1></div>
                    <div className={addProForms.box}>
                        
                    <input type="text" value={Stock} onChange={e => setStock(e.target.value)} placeholder="No." className={addProForms.box}/>
            </div>
            </div>
            </div>

            <div className={addProForms.flexc}>
            <div className={addProForms.roles}>
            <div className={addProForms.rolename}>
                <h1>Status: </h1>
            </div>
            <div className={addProForms.Bgs}>
         <div className={addProForms.Bigr1}>
            <div className={addProForms.input}>
            <input type="radio" name="role" value="มีสินค้า" className={addProForms.input} onChange={(event) => setStatus(event.target.value)}/>
            
            </div>
            <div className={addProForms.label}>
            <h1>มีสินค้า</h1>
            </div>
            </div>
            
            <div className={addProForms.Bigr2}>
            <div className={addProForms.input}>
            <input type="radio" name="role" value="ไม่มีสินค้า" className={addProForms.input} onChange={(event) => setStatus(event.target.value)}/>
            </div>
            <div className={addProForms.label}>
            <h1>ไม่มีสินค้า</h1>
            </div>
            </div>
            </div>
            </div>
           
            <div className={addProForms.bigger}>
            <div className={addProForms.name}><h1>Description:</h1></div>
                    <div className={addProForms.boxDS}>
                        
                   
                    <input type="text" value={Description} onChange={e => setDescription(e.target.value)} placeholder="Description" className={addProForms.boxDS}/>
            </div>
            </div>
            </div>
            <div className={addProForms.butt}>
            <button type="submit" >Update</button>
            </div>
          

            {/* // พลวัต ชาญศิขริน อ๋อง -->*/}
{updateStatus && updateStatus.success && <Success message={"Update Successful"} />}
{updateStatus && !updateStatus.success && <Bug message={"Update Failed"} />} 
        </form>
        </>
    );
}
export default UpdateProForm;
// <-- พลวัต ชาญศิขริน อ๋อง






