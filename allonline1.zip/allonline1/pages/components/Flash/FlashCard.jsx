{/* Boonyarit Modepeng Benz page design */}
import React from "react"
import Slider from "react-slick"
import "slick-carousel/slick/slick.css"
import "slick-carousel/slick/slick-theme.css"
import Image from "next/image"
import { useState, useEffect } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCaretRight } from "@fortawesome/free-solid-svg-icons"
import { faCaretLeft } from "@fortawesome/free-solid-svg-icons"
import { faStar } from "@fortawesome/free-solid-svg-icons"
import Axios from "axios";
import Link from "next/link";

const SampleNextArrow = (props) => {
  const { onClick } = props
  return (
    <div className='control-btn' onClick={onClick}>
      <button className='next'>
      <i><FontAwesomeIcon className='faright' icon={faCaretRight} /></i>{/* Click on next slide */}
      </button>
    </div>
  )
}
const SamplePrevArrow = (props) => {
  const { onClick } = props
  return (
    <div className='control-btn' onClick={onClick}>
      <button className='prev'>
      <i><FontAwesomeIcon className='faleft' icon={faCaretLeft} /></i>{/* Click on previous slide */}
      </button>
    </div>
  )
}
const FlashCard = () => {  
  const [ProID,setProID] = useState([null]);
const handleEdit = (ProID) =>{
  console.log(ProID)
  setProID(ProID)
}
  const [productList, setProductList] = useState([]);

  const getProduct = () => {
    Axios.get("http://localhost:3001/flashdeal").then((response) => { 
      setProductList(response.data);
    });
  };

  useEffect(() => {
    getProduct();
  }, []);
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    nextArrow: <SampleNextArrow />,
    prevArrow: <SamplePrevArrow />,
    responsive: [
      {
        breakpoint: 941,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 624,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 555,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ],
  }
  
  return (
    <>
      <Slider {...settings}>
      {productList.map((val) => {
          return (
            
            <div className='box' key={val.ProID}>
               <Link href={`/Flash/${val.ProID}`} onClick={() => handleEdit(val.ProID)}>
              <div className='product mtop'>
                <div className='img '>
                  <span className='discount'>{val.Sale} Off</span>
                  <img
                  className="coverf"
                  src={`/storage/${val.ProIMG}`}
                  alt=""
                  />
                </div>

              
                <div className='product-details'>
                  <h3>{val.Proname}</h3>
                  <div className='rate'>
                  <i><FontAwesomeIcon className='fastarf' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastarf' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastarf' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastarf' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastarf' icon={faStar} /></i>
                </div>

                <div className="aprice">
                  <div className="Sprice"><h4>฿{val.Flash}</h4></div>
                  <div className='Pprice'><h4>฿{val.Price} </h4></div>
                  </div>
               
                </div>
              </div>
              </Link>
            </div>
          )
        })}
      </Slider>
    </>
  )
}

export default FlashCard
