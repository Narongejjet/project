{/* Boonyarit Modepeng Benz data to show in advertisement*/}
const Sdata = [
    {
      id:1,
      cover: 'https://www.allonline.7eleven.co.th/media/i/Allonline_Feb-Cake_banner_893x310-(1)-192957-0.jpg',
      url:'https://youtu.be/dQw4w9WgXcQ',
    },
    {
      id:2,
      cover: 'https://www.allonline.7eleven.co.th/media/i/1-SEWA-Pro-7-11-01-193658-0.jpg',
      url:'https://youtu.be/dQw4w9WgXcQ',
    },
    {
      id:3,
      cover: 'https://www.allonline.7eleven.co.th/media/i/WELCOME-เครื่องชงกาแฟสุดคลาสสิค-(2-Feb---20-feb-2023)-194309-0.jpg',
      url:'https://youtu.be/dQw4w9WgXcQ',
    },
    {
      id:4,
      cover: 'https://www.allonline.7eleven.co.th/media/i/AO_893x310-194123-0.jpg',
      url:'https://youtu.be/dQw4w9WgXcQ',
    },
    

  ]
  export default Sdata
  