// พลวัต ชาญศิขริน อ๋อง-->
import { useState } from "react";
import AddProForm from "./addProForm";
import UpdateProForm from "./updateProForm";
import * as React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faRectangleXmark } from "@fortawesome/free-solid-svg-icons";
import Admins from '../styles/Admins.module.css'

export default function ProForm(){

    const flag=true;  
    {/* Boonyarit Modepeng Benz-- close button> */}
    const [anchorEl, setAnchorEl] = React.useState(null);
    const handleClose = () => {
        setAnchorEl(null);
      };

    return(
        <>
        {/* Boonyarit Modepeng Benz-- design form> */}
             <div className={Admins.Cform}>
                <form>
             <button className={Admins.close}><i><FontAwesomeIcon  icon={ faRectangleXmark } onClick={() => { handleClose();}} /></i></button>
             </form>
             </div>
             
        <div className='contai'>
            {flag?<AddProForm/>:<UpdateProForm/>}
        </div>
        </>
    )
}

// <--พลวัต ชาญศิขริน อ๋อง