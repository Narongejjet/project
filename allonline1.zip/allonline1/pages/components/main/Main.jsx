{/* Boonyarit Modepeng Benz get category and slider to show in main page*/}
import React from "react"
import Category from "./Category"
import Slider from "./Slider"


const Main = () => {
  return (
    <>
     
      <div className='home'>
        <div className='container d_flex'>
          <Category />

          <Slider />
      
        </div>
        
      </div>
     
    </>
  )
}

export default Main
