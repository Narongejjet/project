{/* Boonyarit Modepeng Benz category bar*/}
import React from "react"
import Image from 'next/image';
import Link from 'next/link'
/*Import image*/
import Image1 from '../../../public/img/category/cat4.png'
import Image2 from '../../../public/img/category/cat3.png'
import Image3 from '../../../public/img/category/cat2.png'
import Image4 from '../../../public/img/category/cat1.png'

const Category = () => {
  const data = [
    {
      cateImg: Image1,
      cateName: "อาหารและเครื่องดื่ม",
    },
    {
      cateImg: Image2,
      cateName: "ความงาม",
    },
    {
      cateImg: Image3,
      cateName: "อุปกรณ์ไอทีและกล้อง",
    },
    {
      cateImg: Image4,
      cateName: "เครื่องใช้ไฟฟ้า",
    }
  
  ]

  return (
    <>
  
  <div className='category'>
      {data.map((value, index) => {
    return (
        <div className='box f_flex' key={index}>
            <Image src={value.cateImg} alt="" />
            <Link href="/all/name" as={`/all/${value.cateName}`}>
                <p className={`cateName${index+1}`}>{value.cateName}</p>
            </Link>
        </div>
)

})}

      </div>
    </>
  )
}

export default Category
