{/* Boonyarit Modepeng Benz all page design */}
import React from 'react'
import Navbar from '../../header/Navbar'
import Footer from '../../Footer/Footer'
import Catg from '../Beauty/Catg'
import Apliancecart from './Apliancecart'

import Style from './Style.module.css'

function Apliance() {
  return (
    <>
    <Navbar/>
    <section className='scat background'>
        <div className='container d_flex'>
          <Catg />

          <div className={Style.contentWidth}>
            <div className='heading d_flex'>
            <div className='heading-left row  f_flex'>
                <h2 className={Style.ctitle}>เครื่องใช้ไฟฟ้า</h2>
              </div>
            </div>
            <div className='product-content  grid10'>
              <Apliancecart/>
            </div>
          </div>
        </div>
      </section>
    <Footer/>
    </>
  )
}

export default Apliance