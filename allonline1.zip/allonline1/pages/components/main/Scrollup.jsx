{/* Boonyarit Modepeng Benz scroll up button*/}
import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleArrowUp } from "@fortawesome/free-solid-svg-icons";
import Style from './Style.module.css'
const Scrollup = () => {
  const [showScroll, setShowScroll] = useState(false);

  useEffect(() => {
    const checkScrollTop = () => {
      if (!showScroll && window.pageYOffset > 400) {
        setShowScroll(true);
      } else if (showScroll && window.pageYOffset <= 400) {
        setShowScroll(false);
      }
    };
    window.addEventListener("scroll", checkScrollTop);
    return () => window.removeEventListener("scroll", checkScrollTop);
  }, [showScroll]);

  const scrollTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className={Style.scrolltotop}>
      {showScroll && (
        <div className={Style.scroll} onClick={scrollTop}>
          <i><FontAwesomeIcon className='faCircleArrowUp' icon={faCircleArrowUp} /></i>
        </div>
      )}
    </div>
  );
};

export default Scrollup;
