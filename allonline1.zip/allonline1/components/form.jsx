// พลวัต ชาญศิขริน อ๋อง -->
import UpdateUserForm from "./updateUserForm";
import Admins from '../styles/Admins.module.css'
import * as React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faRectangleXmark } from "@fortawesome/free-solid-svg-icons";

export default function Form(){
//Boonyarit Modepeng Benz close form button-->
    const [anchorEl, setAnchorEl] = React.useState(null);
    const handleClose = () => {
        setAnchorEl(null);
      };


    const flag=true;  
   
    return(
   <>
{/* Boonyarit Modepeng Benz design page form-->*/}
            <div className={Admins.Uform}>
                     <form>
             <button className={Admins.close}><i><FontAwesomeIcon  icon={ faRectangleXmark } onClick={() => { handleClose();}} /></i></button>
             </form>
             </div>
        <div className={Admins.form}>
            {<UpdateUserForm/>}
        </div>
      
        </>
    )
}
// <--พลวัต ชาญศิขริน อ๋อง