{/* Boonyarit Modepeng Benz -->*/}
import React from "react"
import Image from "next/image"
import Axios from "axios";
/*Font awesome*/ 
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faStar } from "@fortawesome/free-solid-svg-icons"
import { SliderValueLabel } from "@mui/material"
import Link from "next/link"
import { useState, useEffect } from "react";
const ShopCart = ({shopsearch}) => {  
  //Get product from this api
  const [productList, setProductList] = useState([]);
  const getProduct = () => {
    Axios.get("http://localhost:3001/product").then((response) => {
      setProductList(response.data);
    });
  };

  const searchPro = shopsearch(productList)//Add searchfilter to productlist 
  
const [ProID,setProID] = useState([null]);

const handleEdit = (ProID) =>{
  console.log(ProID)
  setProID(ProID)
}
  useEffect(() => {
    getProduct();
  }, []);

  return (
    <>
      {searchPro.length > 0 ?  searchPro.map((val) => {
          return (
            
            <div className='box' key={val.ProID}>
              <Link href={`/Detail/${val.ProID}`} onClick={() => handleEdit(val.ProID)}>
              <div className='product mtop'>
                <div className='img'>
                  {/* <span className='discount'>{shopItems.discount}% Off</span> */}
                  <img
                  className="cover"
                  // พลวัต ชาญศิขริน อ๋อง -->
                  src={`/storage/${val.ProIMG}`}
                  // <--พลวัต ชาญศิขริน อ๋อง
                  alt=""
                  />
                </div>
              
                <div className='product-details'>
                  <h3>{val.Proname}</h3>
                  <div className='rate'>
                  <i><FontAwesomeIcon className='fastar' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastar' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastar' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastar' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastar' icon={faStar} /></i>
                </div>
                  <div className='price'>
                    <h4>${val.Price}.00 </h4>
                  </div>
                </div>
              </div>
              </Link>
            </div>
          )
        })
      : <h2>ไม่พบสินค้า</h2>
      }
   
    </>
  )
}

export default ShopCart
