// พลวัต ชาญศิขริน อ๋อง -->
import React from 'react';
import { MDBTable, MDBTableHead, MDBTableBody } from 'mdb-react-ui-kit';
import 'mdb-react-ui-kit/dist/css/mdb.min.css'
import Axios from "axios";
import { useState, useEffect } from "react";

export default function Table() {
    const [customersList, setCustomersList] = useState([]);

    const getCustomers = () => {
        Axios.get('http://localhost:3001/customers').then((response) => {
            setCustomersList(response.data);
        });
    }

    useEffect(() => {
        getCustomers()
    }, [])
{/* Boonyarit Modepeng Benz desgin table--> */}
    return (
        <MDBTable>
            <MDBTableHead dark>
                <tr>
                    <th scope='col'>CustomerID</th>
                    <th scope='col'>E-mail</th>
                    <th scope='col'>Firstname</th>
                    <th scope='col'>LAstname</th>
                    <th scope='col'>Types</th>

                </tr>
            </MDBTableHead>

            {customersList.map((val, key) => {
                return (
                    <MDBTableBody>
                        <tr>
                            <td>
                                <span className="text">{val.id}</span>
                            </td>
                            <td>
                                <span>{val.email}</span>
                            </td>
                            <td>
                                <span>{val.fname}</span>
                            </td>
                            <td >
                                <span>{val.lname}</span>
                            </td>
                            <td>
                                <span>{val.role}</span>
                            </td>
                        </tr>
                    </MDBTableBody>
                )
            })}

        </MDBTable>
    );
}
// <--พลวัต ชาญศิขริน อ๋อง