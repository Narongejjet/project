{/* Boonyarit Modepeng Benz page design*/}
import React from "react"
import FlashCard from "./FlashCard"
import Image from "next/image"


const FlashDeals = () => {
  
  return (
    <>
      <section className='flash'>
        <div className='container'>
          <div className='heading f_flex'>
            <Image
            className="sale"
            src='https://www.allonline.7eleven.co.th/ba7474182b545399b2933a530b66c307c38b1c0d/assets/7online/images/flashsale/flashsaleheader_logo.svg'
            alt=""
            width={150}
            height={150}
            />
          
          </div>
          <FlashCard/>
        </div>
      </section>
    </>
  )
}

export default FlashDeals
