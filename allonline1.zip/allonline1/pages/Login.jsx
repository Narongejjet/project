//Narongdej Santaweesuk login user.-->
import React from "react";
import Link from "next/link";
import { useEffect } from "react";
import GoogleLogin from "react-google-login";
import { gapi } from "gapi-script";
import Swal from 'sweetalert2'
import { Fullscreen, Title } from "@mui/icons-material";
export default function LogIn() {
  
  const clientId = "416073157022-ukou3a84kfrdrvgp80crr49hu9s3psie.apps.googleusercontent.com"; // Id from gapi.

  useEffect(() => {
      function start() {
          gapi.client.init({
              clientID: clientId,
              scope: ""
          })
      };
      gapi.load("client:auth2", start);
  }, []);

  const onSuccess = (res) => {
      console.log("LOGIN SUCCESS! Current user: ", res.profileObj);
      window.location = '/'
  }

  const onFailure = (res) => {
      console.log("LOGIN FAILED! res: ", res);
      alert('Login Failed!')
  }
  
  
  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const jsonData = {
      email: data.get("email"),
      password: data.get("password"),
    };

    fetch("http://localhost:3333/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(jsonData),
    })
      .then((response) => response.json())
      .then((data) => {
      {/* Boonyarit Modepeng Benz alert-->*/}
        if (data.status === "ok") {
          Swal.fire({
            title:'เข้าสู่ระบบสำเร็จ',
            icon:'success',
          })
          
          localStorage.setItem("token", data.token);
          setTimeout(function(){
            window.location="/"
          },2000)
        } else {
          {/* Boonyarit Modepeng Benz alert-->*/}
          Swal.fire({
            title:'ผิดพลาด',
            text:'รหัสผ่านของคุณไม่ถูกต้อง',
            icon:'error',
          })
       
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      });
      
  };
//Narongdej Santaweesuk

{/* Boonyarit Modepeng Benz -->*/}
  return (
    
    <div className="wrapper Log" >
      <div className="title-text">
        <div className="title login">
          <h1>เข้าสู่ระบบ</h1>
        </div>
      </div>
      <div className="form-container">
        <div className="form-inner">
          <form action="#" className="login" onSubmit={handleSubmit}>
            <div className="field">
              <input
                type="email"
                placeholder="อีเมล"
                id="email"
                name="email"
             
                required
              ></input>
            </div>
            <div className="field">
              <input
                type="password"
                placeholder="รหัสผ่าน"
                id="password"
                name="password"
               
                required
              ></input>
            </div>
           
            <div className="field btn">
              <div className="btn-layer"></div>
              <input type="submit" value="Login"></input>
            </div>
            <div className="signup-link">
              ไม่ได้เป็นสมาชิก? <Link href="/Register">ลงทะเบียนตอนนี้</Link>
            </div>
            <div className="Or">
              ----หรือ---- 
            </div>
            {/* <-- Boonyarit Modepeng Benz */}

            {/* Narongdej Santaweesuk */}
            <div className="Google">
            <GoogleLogin  className='Gform'
                                clientId={clientId}
                                buttonText="เข้าสู่ระบบด้วย Google"
                                onSuccess={onSuccess}
                                onFailure={onFailure}
                                cookiePolicy={'single_host_origin'}
                                
                            />
            </div>
            {/* Narongdej Santaweesuk */}

            <div className="back">
            <div className="signup-link">
            <Link href="/">กลับสู่หน้าหลัก</Link>
            </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
