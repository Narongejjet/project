// พลวัต ชาญศิขริน อ๋อง-->
import { BiEdit, BiTrashAlt } from "react-icons/bi";
import Axios from "axios";
import { useState, useEffect } from "react";
import UpdateProForm from "./updateProForm";
import { MDBTable, MDBTableHead, MDBTableBody } from 'mdb-react-ui-kit';
import 'mdb-react-ui-kit/dist/css/mdb.min.css'
import Product from '../styles/Product.module.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPenToSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrashCan } from "@fortawesome/free-solid-svg-icons";

export default function ProTable() {
  const [selectedProID, setSelectedProID] = useState(null);
  const [formVisible, setFormVisible] = useState(false);
  const [productList, setProductList] = useState([]);

  const getProduct = () => {
    Axios.get("http://localhost:3001/product").then((response) => {
      setProductList(response.data);
    });
  };

  useEffect(() => {
    getProduct();
  }, []);

  const handleEdit = (ProID) => {
    console.log(ProID)
    setSelectedProID(ProID);
    setFormVisible(true);
    setFormVisible(!formVisible)
    window.scrollTo(0, 0);
  };

  function handleDelete(ProID) {
    if (!window.confirm("คุณต้องการที่จะลบสินค้าชิ้นนี้หรือไม่")) {
        return;
      }
      
    Axios.delete(`http://localhost:3001/product/delete/${ProID}`)
    .then((response) => {
        console.log(response.data);
        setProductList(productList.filter((item) => item.ProID !== ProID));
      })
      .catch((error) => {
        console.log(error);
      });
  }

  return (
    <div className={Product.Table}>
      {formVisible && selectedProID ? (
        <UpdateProForm ProID={selectedProID} />
      ) : null}
        <MDBTable>
    {/* Boonyarit Modepeng Benz design table-->*/}
       <MDBTableHead dark>
                <tr className={Product.center}>
                    <th scope='col'>ProductID</th>
                    <th scope="col">Image</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Sale</th>
                    <th scope="col">Flashsale</th>
                    <th scope="col">Description</th>
                    <th scope="col">Stock</th>
                    <th scope="col">Status</th>
                    <th scope="col">Actions</th>
                </tr>
                </MDBTableHead>

            {productList.map((val) => {
                return (
                <>
                      {formVisible && selectedProID ? (
                        <UpdateProForm ProID={selectedProID} />
                      ) : null}
                      <MDBTableBody>
                      <tr className={Product.all} key={val.ProID}>
                        <td>
                        <span>{val.ProID}</span>
                    </td>
                    <td>
                    <img src={`/storage/${val.ProIMG}`} alt="" width={100} />
                        
                    </td>
                    <td>
                        <span>{val.Proname}</span>
                    </td>
                    <td>
                        <span>{val.Price}</span>
                    </td>
                    <td>
                        <span>{val.Sale}</span>
                    </td>
                    <td>
                        <span>{val.Flash}</span>
                    </td>
                    <td>
                        <span>{val.Description}</span>
                    </td>
                    <td>
                        <span>{val.Stock}</span>
                    </td>
                    <td>
                        <span>{val.Status}</span>
                    </td>
                    <td>
                  
                        <div className={Product.edit}>
        <FontAwesomeIcon className={Product.edit} icon={faPenToSquare} onClick={() => handleEdit(val.ProID)} />
        </div>
        <div className={Product.del}>
        <FontAwesomeIcon className={Product.del} icon={faTrashCan} onClick={() => handleDelete(val.ProID)} />
        </div>
                    </td>
                </tr>
                </MDBTableBody>
                </>
            )    
        })}
       
       </MDBTable>
   </div>
    )
    }
   // <--พลวัต ชาญศิขริน อ๋อง