{/* Boonyarit Modepeng Benz navbar design*/}
import React, { useEffect,useState } from 'react';
import logo from '../../../public/img/logo.png'
import Image from 'next/image';
import Dropdown from './Dropdown';
import Hamburger from './Hamburger'
import Link from 'next/link';
import AccountMenu from '../Profile/Profile';

//Font awesome import
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import { faHeadset } from '@fortawesome/free-solid-svg-icons';
import { faBars } from '@fortawesome/free-solid-svg-icons';


const Navbar = ({inseacrh}) => {
  const [get,setGet] = useState('')
  
    useEffect(() => {
        const header = document.querySelector('.header .header-1');
        if (header) {
          window.onscroll = () => {
            if (window.scrollY > 80) {
              header.classList.add('active');
            } else {
              header.classList.remove('active');
            }
          };
        }
      }, []);
      
      

  return (
   
    <header className="header">
    
    <div className="header-1">
    <Hamburger/>
    <Link href="/" className="logo"> <Image
         
          src={logo}
          alt="Allonline Logo"
          width={100}
          height={60}
        /> </Link>

<form action="" className="search-form">
        <label><FontAwesomeIcon className='fasearch' icon={faSearch} onClick={()=>inseacrh(get)}/></label>
        <input type="search"  placeholder="search here..." id="search-box" onChange={(e)=>setGet(e.target.value)}/>
            <span><Dropdown/></span>
        </form>

        <div className="icons" >
        <div id="search-btn" className="search"><FontAwesomeIcon className='fasearch' icon={faSearch} /></div>
            <Link href="/" className="headset"><FontAwesomeIcon className='faheadset' icon={faHeadset} /></Link>
            <Link href="/components/Cart/Cart" className="cart"> <FontAwesomeIcon className='facart' icon={faShoppingCart} /></Link>
            <AccountMenu/>
            
        </div>

    </div>

    <div className="header-2">
        <nav className="navbar">
            <Link href="/">สินค้าขายดี</Link>
            <Link href="/">สินค้าโปรโมชั่น</Link>
            <Link href="/">สินค้ามาใหม่</Link>
            <Link href="/">รวมคูปองส่วนลด</Link>
            <Link href="/">Flash sale</Link>
        </nav>
    </div>

    </header>
  
    
  )
}


export default Navbar