//Narongdej Santaweesuk register.-->
import React, { useState, useEffect } from 'react';
import Link from 'next/link'
import Swal from 'sweetalert2'
import Script from 'next/script';
import ReCAPTCHA from "react-google-recaptcha";
import GoogleLogin from "react-google-login";
import { gapi } from "gapi-script";

export default function SignUp() {

  const [confirmPassword, setConfirmPassword] = useState('')

  const [passwordShown, setPasswordShown] = useState(false);

  //show password
  const togglePassword = () => {
    setPasswordShown(!passwordShown);
  };

  const onChange = () => { };

  const clientId = "416073157022-ukou3a84kfrdrvgp80crr49hu9s3psie.apps.googleusercontent.com";

  useEffect(() => {
    function start() {
      gapi.clinet.init({
        clientID: clientId,
        scope: ""
      })
    };
    gapi.load("client:auth2", start);
  }, []);

  const onSuccess = (res) => {
    console.log("LOGIN SUCCESS! Current user: ", res.profileObj);
    window.location = '/'
  }

  const onFailure = (res) => {
    console.log("LOGIN FAILED! res: ", res);
    alert('Login Failed!')
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const password = data.get('password');
    const confirmPassword = data.get('confirmPassword');

    if (password !== confirmPassword) {   //rechack password ว่าตรงกันหรือเปล่า
      Swal.fire({
        title: 'Error',
        text: 'Password and confirm password do not match',
        icon: 'error'
      })
      return;
    } else if (password.length < 8) {   // รหัสผ่านต้องมีอย่างน้อย 8 ตัวขึ้นไป
      Swal.fire({
        title: 'Error',
        text: 'Enter a password of at least 8 characters.',
        icon: 'error'
      })
      return;
    } else if (!/[a-z]/.test(password)) {    // รหัสผ่านต้องมีภาษาอังกฤษพิมพ์เล็ก
      Swal.fire({
        title: 'Error',
        text: 'Password must contain at least one lowercase letter',
        icon: 'error'
      })
      return;
    } else if (!/[A-Z]/.test(password)) {   // รหัสผ่านต้องมีภาษาอังกฤษพิมพ์ใหญ่
      Swal.fire({
        title: 'Error',
        text: 'Password must contain at least one Uppercase letter',
        icon: 'error'
      })
      return;
    } else if (!/[0-9]/.test(password)) {   // รหัสผ่านต้องมีตัวเลข
      Swal.fire({
        title: 'Error',
        text: 'Password must contain at least one Number.',
        icon: 'error'
      })
      return;
    } else {

    }


    const jsonData = {
      email: data.get('email'),
      password: password,
      fname: data.get('firstName'),
      lname: data.get('lastName')
    }

    fetch('http://localhost:3001/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(jsonData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === 'ok') {
          Swal.fire({
            title: 'เข้าสู่ระบบสำเร็จ',
            icon: 'success',
          });
          window.location = '/';
        } else {
          Swal.fire({
            title: 'คำเตือน',
            text: 'บัญชีนี้ถูกใช้ลงทะเบียนไปแล้ว',
            icon: 'warning',
          });
        }
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };
  //Desgin register page
  return (
    <div className="wrapperR">
      <div className="title-text">
        <div className="title signup">
          <h1>ลงทะเบียน</h1>
        </div>
      </div>
      <div className="form-container">
        <div className="form-inner">
          <form action="#" className="login" onSubmit={handleSubmit}>
            <div className="field">
              <input
                type="text"
                placeholder="ชื่อ"
                id="firstName"
                name="firstName"

                required
              ></input>
            </div>

            <div className='field'>
              <input
                type="text"
                placeholder="นามสกุล"
                id="lastName"
                name="lastName"

                required
              ></input>
            </div>
            <div className="field">
              <input
                type="email"
                placeholder="อีเมล"
                id="email"
                name="email"
                required
              ></input>

            </div>
            <div className="field">
              <input
                type={passwordShown ? "text" : "password"}
                placeholder="รหัสผ่าน"
                id="password"
                name="password"
                required
              />
            </div>
            <div className="field">
              <input
                type={passwordShown ? "text" : "password"}
                placeholder="ยืนยันรหัสผ่าน"
                id="confirmPassword"
                name="confirmPassword"
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                required
              />
            </div>
            <div className='check'>
              <input
                type="checkbox"
                id="showPassword"
                name="showPassword"
                checked={passwordShown}
                onChange={togglePassword}
              />
              <div className='show'>
                <label >Show Password</label>
              </div>
            </div>

            
            <div className="capcha" >
              <ReCAPTCHA
                sitekey="6Lc_EZ8kAAAAACivOSHHjiDfEwqFg4rQSUsNnVmb" onChange={onChange} >

              </ReCAPTCHA>
            </div>
            <div className="field btn">
              <div className="btn-layer"></div>
              <input type="submit" value="ลงทะเบียน"></input>
            </div>
            <div className="Or">
              ----หรือ----
            </div>
            <div className="Google">
              <GoogleLogin className='Gform'
                clientId={clientId}
                buttonText="เข้าสู่ระบบด้วย Google"
                onSuccess={onSuccess}
                onFailure={onFailure}
                cookiePolicy={'single_host_origin'}

              />
            </div>
            <div className="signup-link">
              เป็นสมาชิกอยู่แล้ว? <Link href="/Login">คลิกที่นี่</Link>
            </div>
            <div className="back">
              <div className="signup-link">
                <Link href="/">กลับสู่หน้าหลัก</Link>
              </div>
            </div>
            <Script src="http://www.google.com/recaptcha/api.js" async defer></Script>
          </form>
        </div>
      </div>
    </div>
  );
}