//Narongdej Santaweesuk Jet backend API -->
var express = require('express')
var cors = require('cors')
var app = express()
var bodyParser = require('body-parser')
var jsonParser = bodyParser.json()
const bcrypt = require('bcrypt')
const saltRounds = 10
var jwt = require('jsonwebtoken');
const secret = 'fullstack-login'
const multer = require('multer')

app.use(cors())
app.use(express.json());
app.use(express.urlencoded({ extended: true }))

const mysql = require('mysql2');
const connection = mysql.createConnection('mysql://c65mh8osjqaght4lskrb:pscale_pw_2WpK0cVxpdEcMB44OG1niP4aotba9YHzOa6scv1o3w5@ap-southeast.connect.psdb.cloud/allonline?ssl={"rejectUnauthorized":true}');
//<--Narongdej Santaweesuk Jet

//Boonyarit Modepeng Benz get authorization token when logged in -->
function authenticateToken(req, res, next) {
    // console.log(req.headers);
    const authHeader = req.headers['authorization']
    const token = authHeader //&& authHeader.split(' ')[1]
    // console.log(token);
    if (token == null) return res.sendStatus(401)

    jwt.verify(token, secret, (err, user) => {
      if (err) {
        console.log(err)
        return res.status(403).json({message:"Unauthenticated:For Signed in User Only"})
      }

      req.user = user

      next()
    })
  } 

//พลวัต ชาญศิขริน อ๋อง -->
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, '../public/storage');
    },
    filename: (req, file, cb) => {
        cb(null, `${file.originalname}`);
    },
});

const upload = multer({ storage });
//<--พลวัต ชาญศิขริน อ๋อง

//Boonyarit Modepeng Benz get firstname and lastname-->
app.get('/getlogin',jsonParser,authenticateToken, function (req, res, next) {
  const uid = req.user.id 
  console.log(uid);
    connection.query('Select fname,lname from customers where id = ?',[uid],(err,results)=>{
        if(err){
            res.status(500).send(err)
        } else{
            console.log(results);
            res.send(results)
        }
    }) 
})


//Narongdej Santaweesuk Jet register with email. -->
app.post('/register', jsonParser, function (req, res, next) {
    connection.execute(
        "select * from customers where email = ?", [req.body.email], // caheck ว่า email มีการใช้งานไปแล้วหรือยัง
        function (err, customers) {
            if (err) {
                res.json({ status: 'err' , message:"This email has been taken." })
            } else //ทำการเปลี่ยนรหัสผ่านเพื่อความปลอดภัย
                bcrypt.hash(req.body.password, saltRounds, function (err, hash) {  
                    connection.execute(
                        "INSERT INTO customers (email, password, fname, lname, role) VALUES (?, ?, ?, ?, 'user')",
                        [req.body.email, hash, req.body.fname, req.body.lname],
                        function (err, results, fields) {
                            if (err) {
                                res.json({ status: 'error', message: err })
                                return
                            }
                            res.json({ status: 'ok' })
                        }
                    );
                });
        }
    )
})
//<--Narongdej Santaweesuk Jet

//Narongdej Santaweesuk Jet login user with email. -->
app.post('/login', jsonParser, function (req, res, next) {
    connection.execute(
        'SELECT * FROM customers WHERE email = ?',
        [req.body.email],
        function (err, users, fields) {
            if (err) { res.json({ status: 'error', message: err }); return }

            if (users.length == 0) { res.json({ status: 'error', message: 'no user found' }); return } // check ว่ามี email อยู่ใน database หรือไม่

            //ทำการเทียบรหัสผ่านที่เก็บไว้ในฐานข้อมูลกับที่ user กรอกมาว่าถูกต้องหรือไม่
            bcrypt.compare(req.body.password, users[0].password, function (err, isLogin) {
                if (isLogin) {
                    var token = jwt.sign({ id: users[0].id }, secret, { expiresIn: '1h' });
                    res.json({ status: 'ok', message: 'login success', token })
                } else {
                    res.json({ status: 'error', message: 'login failed' })
                }
            });
        }
    );
})
//<--Narongdej Santaweesuk Jet

//Narongdej Santaweesuk Jet login admin. -->
app.post('/loginAdmin', jsonParser, function (req, res, next) {
    connection.execute(
        'SELECT * FROM admin WHERE email = ?', //login โดย email
        [req.body.email],
        function (err, users, fields) {
            if (err) { res.json({ status: 'error', message: err }); return }

            if (users.length == 0) { res.json({ status: 'error', message: 'no user found' }); return } // check ว่ามี email อยู่ใน database หรือไม่

            //ทำการเทียบรหัสผ่านที่เก็บไว้ในฐานข้อมูลกับที่ user กรอกมาว่าถูกต้องหรือไม่
            bcrypt.compare(req.body.password, users[0].password, function (err, isLogin) {
                if (isLogin) {
                    var token = jwt.sign({ email: users[0].email }, secret, { expiresIn: '1h' });
                    res.json({ status: 'ok', message: 'login success', token })
                } else {
                    res.json({ status: 'error', message: 'login failed' })
                }
            });
        }
    );
})
//<--Narongdej Santaweesuk Jet


//Narongdej Santaweesuk Jet.-->
app.post('/authen', jsonParser, function (req, res, next) {
    try {
        const token = req.headers.authorization.split(' ')[1]
        var decoded = jwt.verify(token, secret);
        res.json({ status: 'ok', decoded })
    } catch (err) {
        res.json({ status: 'error', message: err.message })
    }
})
//<--Narongdej Santaweesuk Jet

//Narongdej Santaweesuk Jet -->
app.listen(3333, jsonParser, function () {
    console.log('CORS-enabled web server listening on port 3333')
})
//<--Narongdej Santaweesuk Jet

//พลวัต ชาญศิขริน อ๋อง -->
app.get('/customers', (req, res) => {
    connection.query(`SELECT id, email, fname, lname, role FROM customers`, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.send(results);
        }
    });
});
app.put('/customers/update/:id', (req, res) => {
    const id = req.params.id;
    const updateData = req.body;
    const query = `UPDATE customers SET email = '${updateData.email}', fname = '${updateData.fname}', lname = '${updateData.lname}', role = '${updateData.role}' WHERE id = ${id}`;

    connection.query(query, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.send(results);
        }
    });
});
app.get('/product', (req, res) => {
    connection.query(`SELECT * FROM Product`, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.send(results);
        }
    });
});
//<--พลวัต ชาญศิขริน อ๋อง

//<--พลวัต ชาญศิขริน อ๋อง

app.get('/product/:id', (req, res) => {
    const id = req.params.id;
    connection.query(`SELECT * FROM Product WHERE ProID = ?`, [id], (err, results) => {
      if (err) {
        res.status(500).send(err);
      } else {
        res.send(results[0]);
      }
    });
  });

  
//Boonyarit Modepeng Benz get only beauty product category-->
app.get('/productbeauty', (req, res) => {
    connection.query(`SELECT * FROM Product where ProID like '2%'`, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.send(results);
        }
    });
});
//Boonyarit Modepeng Benz get only apliance product category-->
app.get('/productapliance', (req, res) => {
    connection.query(`SELECT * FROM Product where ProID like '4%'`, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.send(results);
        }
    });
});
//Boonyarit Modepeng Benz get only productfood product category-->
app.get('/productfood', (req, res) => {
    connection.query(`SELECT * FROM Product where ProID like '1%'`, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.send(results);
        }
    });
});
//Boonyarit Modepeng Benz get only gadget product category-->
app.get('/productgadget', (req, res) => {
    connection.query(`SELECT * FROM Product where ProID like '3%'`, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.send(results);
        }
    });
});

//<--Narongdej Santaweesuk Jet, Boonyarit Modepeng Benz, พลวัต ชาญศิขริน อ๋อง get selected id when clicked on product
app.get('/product/detail/:id', (req, res) => {
    const ProID = req.params.id
    connection.query(`SELECT * FROM Product where ProID = ${ProID}`, (err, results)=> {
        if (err) {
            res.status(500).send(err);
            console.log(err)
        } else {
            res.send(results);
        }
    });
})
//<--Narongdej Santaweesuk Jet, Boonyarit Modepeng Benz, พลวัต ชาญศิขริน อ๋อง get selected id when clicked on flash product

app.get('/product/flash/:id', (req, res) => {
    const ProID = req.params.id
    connection.query(`SELECT * FROM Product where ProID = ${ProID}`, (err, results)=> {
        if (err) {
            res.status(500).send(err);
            console.log(err)
        } else {
            res.send(results);
        }
    });
})
//Boonyarit Modepeng get only flash product
app.get('/flashdeal', (req, res) => {
    connection.query(`SELECT * FROM Product where Flash`, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.send(results);
        }
    });
});


//พลวัต ชาญศิขริน อ๋อง -->
app.post("/product/add", upload.single('ProIMG'), (req, res) => {
    // Check if there is a file in the request body
    if (!req.file) {
        res.status(400).send("ไม่มีรูปภาพ");
        return;
    }

    // Get the uploaded file information
    const ProIMG = req.file.filename;
    const { ProID, Proname, Price, Sale, Flash, Description, Stock, Status } = req.body;
    
    // Store the product information and file name in the database
    let query = `INSERT INTO Product (ProID, ProIMG, Proname, Price, Description, Stock, Status) VALUES ('${ProID}', '${ProIMG}', '${Proname}', '${Price}', '${Description}', '${Stock}', '${Status}')`;
    if (Sale && Flash) {
        query = `INSERT INTO Product (ProID, ProIMG, Proname, Price, Sale, Flash, Description, Stock, Status) VALUES ('${ProID}', '${ProIMG}', '${Proname}', '${Price}', '${Sale}', '${Flash}', '${Description}', '${Stock}', '${Status}')`;
    } else if (Sale) {
        query = `INSERT INTO Product (ProID, ProIMG, Proname, Price, Sale, Description, Stock, Status) VALUES ('${ProID}', '${ProIMG}', '${Proname}', '${Price}', '${Sale}', '${Description}', '${Stock}', '${Status}')`;
    } else if (Flash) {
        query = `INSERT INTO Product (ProID, ProIMG, Proname, Price, Flash, Description, Stock, Status) VALUES ('${ProID}', '${ProIMG}', '${Proname}', '${Price}', '${Flash}', '${Description}', '${Stock}', '${Status}')`;
    }

    connection.query(query, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.send(results);
        }
    });
});
app.put('/product/update/:id', upload.single('ProIMG'), (req, res) => {
    const ProID = req.params.id;
    let query = 'UPDATE Product SET';
    let queryParams = [];
    const updateData = req.body;

    // Check which fields to update
    if (updateData.Proname) {
        queryParams.push(`Proname = '${updateData.Proname}'`);
    }
    if (updateData.Price) {
        queryParams.push(`Price = '${updateData.Price}'`);
    }
    if (updateData.Sale) {
        queryParams.push(`Sale = '${updateData.Sale}'`);
    }
    if (updateData.Flash) {
        queryParams.push(`Flash = '${updateData.Flash}'`);
    }
    if (updateData.Description) {
        queryParams.push(`Description = '${updateData.Description}'`);
    }
    if (updateData.Stock) {
        queryParams.push(`Stock = '${updateData.Stock}'`);
    }
    if (updateData.Status) {
        queryParams.push(`Status = '${updateData.Status}'`);
    }
    // Check if there is a file in the request body
    if (req.file) {
        const ProIMG = req.file.filename;
        queryParams.push(`ProIMG = '${ProIMG}'`);
    }

    if (queryParams.length === 0) {
        res.status(400).send({ message: "ไม่มีข้อมูลให้อัปเดต" });
        return;
    }
    query += ' ' + queryParams.join(', ') + ` WHERE ProID = ${ProID}`;

    connection.query(query, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else if (results.affectedRows === 0) {
            res.status(404).send({ message: "ไม่พบข้อมูลสินค้า" });
        } else {
            res.send(results);
        }
    });
});
app.delete('/product/delete/:id', (req, res) => {
    const query = `DELETE FROM Product WHERE ProID = ${req.params.id}`;

    connection.query(query, (err, results) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.send(results);
        }
    });
});
//<--พลวัต ชาญศิขริน อ๋อง


app.listen(3001, () => {
    console.log('Server started on port 3001');
});