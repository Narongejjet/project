{/* Threerathida boonklom page design*/}
import { padding, textAlign } from '@mui/system';
import React from 'react'
import Detail from './Detail.module.css';
import Link from 'next/link';
import Navbar from '../header/Navbar';
import Footer from '../Footer/Footer'
import { useState } from 'react';
function FlashDetail({Flash}) {
  const [cart,setCart] = useState([])
const handleEdit = (ProID) =>{
console.log(ProID)
  setSelectedProID(ProID)
}
  const addToCart = (ProID) => {
    const cartItem = { ProID};
    setCart([...cart, cartItem]);
    console.log(cart);
  };
  return (
    
    <>
    <Navbar/>
      {Flash.map((val) => {
        return (
          <div className='box' key={val.ProID}>
        

        <section className={Detail.sproduct}>
          <div className={Detail.row}>
          <div >
              <img className={Detail.imgFluid}  src={`/storage/${val.ProIMG}`} alt="" />
            </div>

            <div className={Detail.dete}>
              <div className="col-lg-6 col-md-12 clo-12">
                <div className={Detail.code}>รหัสสินค้า {val.ProID}</div>
                
                <h3 className={Detail.py4}><div className={Detail.pyall}>{val.Proname}<span class={Detail.badge}>New</span></div></h3>
                
                <div className={Detail.PF}>
                <div className={Detail.Flash}>
                <h2>฿{val.Flash}</h2>
                </div>
                    <div className={Detail.Price}>
                <h2>฿{val.Price}</h2>
                </div>
              
                </div>
                <div className={Detail.box}>
                <input  type="number" min="1" max="10"></input>
                </div>
                <div className={Detail.allbtn}>
                <div className={Detail.btnCart}>
                <button className={Detail.buyBtn} >ซื้อสินค้า</button>
                </div>

                <div className={Detail.btnCart}>
                <button className={Detail.addBtn} onClick={() => addToCart(val.ProID)}>เพิ่มลงรถเข็น</button>
                </div>
                </div>
                <div className={Detail.pd}>
                <div className="mt-5 mb-5">คุณสมบัติ:</div>
                </div>
                <span>
                <div className={Detail.pdes}>{val.Description}</div>
                </span>
              </div>
            </div>
          </div>
        </section>
        <section>
       
        <hr className={Detail.rouded} />

        <div className={Detail.daw}>User Rating <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star"></span>
        </div>
        <div className={Detail.review}>reviews</div>

        <p>5 star</p>
        <div class={Detail.star} style={{textAlign: 'right', paddingTop: '2px', paddingBottom : '6px', color: 'white'}}>
        <div class={`${Detail.r5}`} style={{backgroundColor: '#04AA6D'}}>60%</div>
        </div>

        <p>4 star</p>
        <div class={Detail.star} style={{textAlign: 'right', paddingTop: '2px', paddingBottom : '6px', color: 'white'}}>
        <div class={`${Detail.r4}`} style={{backgroundColor: '#2196F3'}}>30%</div>
        </div>

        <p>3 star</p>
        <div class={Detail.star} style={{textAlign: 'right', paddingTop: '2px', paddingBottom : '6px', color: 'white'}}>
        <div class={`${Detail.r3}`} style={{backgroundColor: '#f3e035'}}>10%</div>
        </div>

        <p>2 star</p>
        <div class={Detail.star} style={{textAlign: 'right', paddingTop: '2px', paddingBottom : '6px', color: 'white'}}>
        <div class={`${Detail.r2}`} style={{backgroundColor: '#e29945'}}>4%</div>
        </div>

        <p>1 star</p>
        <div class={Detail.star} style={{textAlign: 'right', paddingTop: '2px', paddingBottom : '6px', color: 'white'}}>
        <div class={`${Detail.r1}`} style={{backgroundColor: '#dd3b3b'}}>15%</div>
        </div>
        </section>
        <div className={Detail.comment}>
          <h2>Comment</h2>
        </div>

        <div className={Detail.mimiAllBox}>
          <div className={Detail.mimiBox}>
            <div className={Detail.boxTop}>
              <div className={Detail.profile}>
                <div className={Detail.profileImg}>
                  <img src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png" alt="" />
                </div>
                <div className={Detail.nameUser}>
                  <strong>Type Monleh</strong>
                  <span>@typerlopper</span>
                </div>
              </div>
            </div>
            <div className={Detail.reviws}>
              <span class="fa fa-star checked"></span>
              <span class="fa fa-star checked"></span>
              <span class="fa fa-star checked"></span>
              <span class="fa fa-star checked"></span>
              <span class="fa fa-star"></span>
            </div>
            <div className={Detail.comment}>
              <p>ดื่มมาตลอดเกือบ 20 ปีแล้วค่ะ ยิ่งดื่มยิ่งรู้สึกดีต่อใจจริงๆค่ะ</p>
            </div>
          </div>
        </div>
  </div>
        )
       })}
       <Footer/>
    </ >
  )
}

export default FlashDetail