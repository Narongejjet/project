{/* Boonyarit Modepeng Benz design page and get&show data from productfood*/}
import React from "react"
import Image from "next/image"
import { useState, useEffect } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faStar } from "@fortawesome/free-solid-svg-icons"
import Axios from "axios";
import Link from "next/link";

const Foodcart = () => {
  const [productList, setProductList] = useState([]);

  const getProduct = () => {
    Axios.get("http://localhost:3001/productfood").then((response) => {
      setProductList(response.data);
    });
  };
  const [ProID,setProID] = useState([null]);
  const handleEdit = (ProID) =>{
    console.log(ProID)
    setProID(ProID)
  }
  useEffect(() => {
    getProduct();
  }, []);

  return (
    <>
      {productList.map((val) => {
          return (
            
            <div className='box' key={val.ProID}>
              <Link href={`/Detail/${val.ProID}`} onClick={() => handleEdit(val.ProID)}>
              <div className='cated mar'>
                <div className='img'>
                  <img
                  className="cover"
                  src={`/storage/${val.ProIMG}`}
                  alt=""
                  />
                </div>

              
                <div className='product-details'>
                  <h3>{val.Proname}</h3>
                  <div className='rate'>
                  <i><FontAwesomeIcon className='fastar' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastar' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastar' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastar' icon={faStar} /></i>
                  <i><FontAwesomeIcon className='fastar' icon={faStar} /></i>
                </div>
                  <div className='price'>
                    <h4>${val.Price}.00 </h4>
                  </div>
                </div>
              </div>
              </Link>
            </div>
          )
        })}
   
    </>
  )
}

export default Foodcart
